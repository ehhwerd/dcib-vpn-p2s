﻿configuration FileServerJoinDomain 
{ 
       
    Import-DscResource -ModuleName PSDesiredStateConfiguration

   
    Node localhost
    {
    	
	    WindowsFeature FileAndStorageServices 
        { 
            Name = "FileAndStorage-Services"
            Ensure = "Present" 		
        }
                
	    WindowsFeature FileServices
	    {
	        Ensure = "Present"
            Name = "File-Services"
	    }

        WindowsFeature StorageServices
	    {
	        Ensure = "Present"
            Name = "Storage-Services"
	    }

        WindowsFeature DataDeduplication
	    {
	        Ensure = "Present"
            Name = "FS-Data-Deduplication"
	    }

        WindowsFeature FSRM
	    {
	        Ensure = "Present"
            Name = "FS-Resource-Manager"
	    }

        WindowsFeature VSS
	    {
	        Ensure = "Present"
            Name = "FS-VSS-Agent"
	    }

        WindowsFeature fsrmMGMT
	    {
	        Ensure = "Present"
            Name = "RSAT-FSRM-Mgmt"
	    } 

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
   }
} 